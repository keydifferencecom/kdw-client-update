<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://
 * @since      1.0.0
 *
 * @package    Newswire
 * @subpackage Newswire/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Newswire
 * @subpackage Newswire/admin
 * @author     
 */
class NewswireAdmin
{

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $newswire_plugin The ID of this plugin.
     */
    private $newswire_plugin;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    /**
     * @var NewswireConnectionTester
     */
    private $connection_tester;

    /**
     * Initialize the class and set its properties.
     *
     * @param string $newswire_plugin The name of this plugin.
     * @param string $version The version of this plugin.
     * @since    1.0.0
     */
    public function __construct($newswire_plugin, $version)
    {

        $this->newswire_plugin = $newswire_plugin;
        $this->version = $version;
        $this->connection_tester = new NewswireConnectionTester($this->newswire_plugin);

    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in NewswireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The NewswireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->newswire_plugin, plugin_dir_url(__FILE__) . 'css/newswire-admin.css', array(), $this->version, 'all');
        wp_enqueue_style('select2.min.css', plugin_dir_url(__FILE__) . 'css/select2.min.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in NewswireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The NewswireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script('select2.min.js', plugin_dir_url(__FILE__) . 'js/select2.min.js', array('jquery'), $this->version, false);
        wp_enqueue_script($this->newswire_plugin, plugin_dir_url(__FILE__) . 'js/newswire-admin.js', array('select2.min.js'), $this->version, false);
        wp_localize_script($this->newswire_plugin, 'NewswireAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('newswire_test_connection'),
            'i18n' => array(
                'runningTests' => __('Running connection tests...', $this->newswire_plugin),
                'unexpectedError' => __('Unable to run connection tests. Please try again.', $this->newswire_plugin),
            ),
        ));
    }

    /**
     * Register the administration menu for this plugin into the WordPress Dashboard menu.
     *
     * @since    1.0.0
     */

    public function add_plugin_admin_menu()
    {

        /*
         * Add a settings page for this plugin to the Settings menu.
         *
         * NOTE:  Alternative menu locations are available via WordPress administration menu functions.
         *
         *        Administration Menus: http://codex.wordpress.org/Administration_Menus
         *
         */
        add_options_page('Newswire', 'Newswire', 'manage_options', $this->newswire_plugin, array($this, 'display_plugin_setup_page')
        );
    }

    /**
     * Add settings action link to the plugins page.
     *
     * @since    1.0.0
     */

    public function add_action_links($links)
    {
        /*
        *  Documentation : https://codex.wordpress.org/Plugin_API/Filter_Reference/plugin_action_links_(plugin_file_name)
        */
        $settings_link = array(
                '<a href="' . admin_url('options-general.php?page=' . $this->newswire_plugin) . '">' . __('Settings', $this->newswire_plugin) . '</a>',
        );
        return array_merge($settings_link, $links);

    }

    /**
     * Render the settings page for this plugin.
     *
     * @since    1.0.0
     */

    public function display_plugin_setup_page()
    {
        include_once('partials/newswire-admin-display.php');
    }

    protected function get_safe_input_field($input, $field, $default_value = null)
    {
        return sanitize_text_field(isset($input[$field]) ? $input[$field] : $default_value);
    }
    protected function get_safe_email_field($input, $field, $default_value = '')
    {
        $value = isset($input[$field]) ? sanitize_email($input[$field]) : '';

        return $value !== '' ? $value : $default_value;
    }

    protected function get_safe_url_field($input, $field, $default_value = '', $allow_relative = false)
    {
        $value = isset($input[$field]) ? trim($input[$field]) : '';

        if ($value === '') {
            return $default_value;
        }

        if ($allow_relative && strpos($value, 'http') !== 0 && !preg_match('/^[a-z0-9]+:/i', $value)) {
            return '/' . ltrim(sanitize_text_field($value), '/');
        }

        $url = esc_url_raw($value);

        return $url !== '' ? $url : $default_value;
    }

    public function validate($input)
    {
        // All checkboxes inputs
        $valid = array();

        //Cleanup
        $valid['token'] = $this->get_safe_input_field($input, 'token');
        $valid['secret'] = $this->get_safe_input_field($input, 'secret');
        $valid['category'] = htmlspecialchars($this->get_safe_input_field($input, 'category'));
        $valid['use_client_image_for_featured_image'] = $this->get_safe_input_field($input, 'use_client_image_for_featured_image', false);
        $valid['add_feature_image_to_post'] = $this->get_safe_input_field($input, 'add_feature_image_to_post', false);
        $valid['additional_categories'] = $this->get_safe_input_field($input, 'additional_categories');
        $valid['post_status'] = $this->get_safe_input_field($input, 'post_status', 'publish');
        $valid['upstream_domain'] = $this->get_safe_url_field($input, 'upstream_domain');
        $valid['author_username'] = $this->get_safe_input_field($input, 'author_username');
        $valid['author_email'] = $this->get_safe_email_field($input, 'author_email');
        $valid['author_first_name'] = $this->get_safe_input_field($input, 'author_first_name');
        $valid['author_last_name'] = $this->get_safe_input_field($input, 'author_last_name', '');
        $valid['author_url'] = $this->get_safe_url_field($input, 'author_url');
        $valid['author_avatar'] = $this->get_safe_url_field($input, 'author_avatar', '', true);
        $valid['author_twitter'] = $this->get_safe_input_field($input, 'author_twitter', '');
        $valid['author_facebook'] = $this->get_safe_input_field($input, 'author_facebook', '');
        $valid['author_google'] = $this->get_safe_input_field($input, 'author_google', '');
        $valid['author_tumblr'] = $this->get_safe_input_field($input, 'author_tumblr', '');
        $valid['author_instagram'] = $this->get_safe_input_field($input, 'author_instagram', '');
        $valid['author_pinterest'] = $this->get_safe_input_field($input, 'author_pinterest', '');
        $valid['unbranded_author_username'] = $this->get_safe_input_field($input, 'unbranded_author_username');
        $valid['unbranded_author_email'] = $this->get_safe_email_field($input, 'unbranded_author_email');
        $valid['unbranded_author_first_name'] = $this->get_safe_input_field($input, 'unbranded_author_first_name');
        $valid['unbranded_author_url'] = $this->get_safe_url_field($input, 'unbranded_author_url');
        $valid['unbranded_author_avatar'] = $this->get_safe_url_field($input, 'unbranded_author_avatar', '', true);
        return $valid;
    }


    public function options_update()
    {
        register_setting($this->newswire_plugin, $this->newswire_plugin, array($this, 'validate'));
    }

    public function handle_test_connection()
    {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('You do not have permission to run these tests.', $this->newswire_plugin)), 403);
        }

        check_ajax_referer('newswire_test_connection');

        $results = $this->connection_tester->run_all_tests();
        $overall_status = $results['overall_status'];
        $message = $overall_status === 'SUCCESS'
            ? __('All tests passed. Your connection looks good.', $this->newswire_plugin)
            : __('Some tests failed. Please review the details below.', $this->newswire_plugin);

        wp_send_json_success(array(
            'overall_status' => $overall_status,
            'message' => $message,
            'results' => $results['results'],
        ));
    }

}
