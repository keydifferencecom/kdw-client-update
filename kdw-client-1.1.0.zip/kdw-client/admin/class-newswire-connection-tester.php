<?php

class NewswireConnectionTester
{
    /**
     * @var string
     */
    private $newswire_plugin;

    public function __construct($newswire_plugin)
    {
        $this->newswire_plugin = $newswire_plugin;
    }

    public function run_all_tests()
    {
        $options = get_option($this->newswire_plugin, array());
        $results = array();

        $results[] = $this->check_credentials($options);
        $results[] = $this->check_upstream_domain($options);
        $results[] = $this->ping_upstream_domain($options);
        $results[] = $this->validate_upstream_credentials($options);

        return array(
            'overall_status' => $this->determine_overall_status($results),
            'results' => $results,
        );
    }

    private function check_credentials($options)
    {
        $token = $this->get_option_value($options, 'token');
        $secret = $this->get_option_value($options, 'secret');
        $has_credentials = $token !== '' && $secret !== '';

        $details = $has_credentials
            ? __('Token and secret are configured.', $this->newswire_plugin)
            : __('Add both token and secret to complete the setup.', $this->newswire_plugin);

        return $this->format_result(
            __('Credentials configured', $this->newswire_plugin),
            $has_credentials,
            $details
        );
    }

    private function check_upstream_domain($options)
    {
        $domain = $this->get_sanitized_domain($options);
        $is_valid = $domain !== '';

        $details = $is_valid
            ? sprintf(__('Upstream domain is set to %s.', $this->newswire_plugin), esc_html($domain))
            : __('Provide a valid upstream domain URL.', $this->newswire_plugin);

        return $this->format_result(
            __('Upstream domain configured', $this->newswire_plugin),
            $is_valid,
            $details
        );
    }

    private function ping_upstream_domain($options)
    {
        $domain = $this->get_sanitized_domain($options);
        if ($domain === '') {
            return $this->format_result(
                __('Upstream domain reachable', $this->newswire_plugin),
                false,
                __('Cannot check reachability because the upstream domain is missing or invalid.', $this->newswire_plugin)
            );
        }

        $response = wp_remote_get($domain, array('timeout' => 10));
        if (is_wp_error($response)) {
            return $this->format_result(
                __('Upstream domain reachable', $this->newswire_plugin),
                false,
                sprintf(
                /* translators: %s: error message */
                    __('Request failed: %s', $this->newswire_plugin),
                    esc_html($response->get_error_message())
                )
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $is_successful = $status_code >= 200 && $status_code < 400;

        $details = sprintf(
        /* translators: 1: HTTP status code, 2: domain */
            __('Received HTTP %1$s from %2$s.', $this->newswire_plugin),
            $status_code,
            esc_html($domain)
        );

        if (!$is_successful) {
            $details .= ' ' . __('Please verify that the upstream endpoint is online.', $this->newswire_plugin);
        }

        return $this->format_result(
            __('Upstream domain reachable', $this->newswire_plugin),
            $is_successful,
            $details
        );
    }

    private function validate_upstream_credentials($options)
    {
        $token = $this->get_option_value($options, 'token');
        $secret = $this->get_option_value($options, 'secret');
        $domain = $this->get_sanitized_domain($options);

        if ($token === '' || $secret === '') {
            return $this->format_result(
                __('Upstream credentials valid', $this->newswire_plugin),
                false,
                __('Cannot verify credentials because the token or secret is missing.', $this->newswire_plugin)
            );
        }

        if ($domain === '') {
            return $this->format_result(
                __('Upstream credentials valid', $this->newswire_plugin),
                false,
                __('Cannot verify credentials because the upstream domain is not configured.', $this->newswire_plugin)
            );
        }

        $endpoint = $domain . '/wp-json/newswire-plugin/v1/article-traces/test';
        $origin_host = wp_parse_url(home_url(), PHP_URL_HOST);
        $headers = array(
            'X-Newswire-Token' => $token,
            'X-Newswire-Signature' => hash_hmac('sha256', $token, $secret),
            'X-Origin-Host' => $origin_host ? $origin_host : '',
        );

        $response = wp_remote_get($endpoint, array(
            'timeout' => 10,
            'headers' => $headers,
        ));

        if (is_wp_error($response)) {
            return $this->format_result(
                __('Upstream credentials valid', $this->newswire_plugin),
                false,
                sprintf(
                /* translators: %s: error message */
                    __('Credential test failed: %s', $this->newswire_plugin),
                    esc_html($response->get_error_message())
                )
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $success = $status_code >= 200 && $status_code < 300;

        $details = __('Received a response from the upstream credential test endpoint.', $this->newswire_plugin);
        if (isset($body['message']) && is_string($body['message'])) {
            $details = $body['message'];
        }

        if (!$success) {
            $details = sprintf(
            /* translators: 1: HTTP status code, 2: endpoint */
                __('Credential test failed with HTTP %1$s from %2$s.', $this->newswire_plugin),
                $status_code,
                esc_html($endpoint)
            );
        }

        return $this->format_result(
            __('Upstream credentials valid', $this->newswire_plugin),
            $success,
            $details
        );
    }

    private function determine_overall_status($results)
    {
        foreach ($results as $result) {
            if ($result['status'] !== 'SUCCESS') {
                return 'ERROR';
            }
        }

        return 'SUCCESS';
    }

    private function format_result($label, $status, $details)
    {
        return array(
            'label' => $label,
            'status' => $status ? 'SUCCESS' : 'ERROR',
            'details' => $details,
        );
    }

    private function get_option_value($options, $key)
    {
        if (!is_array($options) || !array_key_exists($key, $options)) {
            return '';
        }

        $value = trim($options[$key]);
        return sanitize_text_field($value);
    }

    private function get_sanitized_domain($options)
    {
        $domain = $this->get_option_value($options, 'upstream_domain');
        if ($domain === '') {
            return '';
        }

        $sanitized_domain = esc_url_raw($domain);
        return $sanitized_domain ? rtrim($sanitized_domain, '/') : '';
    }
}