(function ($) {
    'use strict';

    /**
     * All of the code for your admin-facing JavaScript source
     * should reside in this file.
     *
     * Note: It has been assumed you will write jQuery code here, so the
     * $ function reference has been prepared for usage within the scope
     * of this function.
     *
     * This enables you to define handlers, for when the DOM is ready:
     *
     * $(function() {
     *
     * });
     *
     * When the window is loaded:
     *
     * $( window ).load(function() {
     *
     * });
     *
     * ...and/or other possibilities.
     *
     * Ideally, it is not considered best practise to attach more than a
     * single DOM-ready or window-load handler for a particular page.
     * Although scripts in the WordPress core, Plugins and Themes may be
     * practising this, we should strive to set a better example in our own work.
     */

    $(window).load(function () {
        // console.log('test2');
        var hidden = $('#newswire-additional_categories');
        var select = $('.multiple-select').select2({
            allowClear: true,
            placeholder: function(){
                $(this).data('placeholder');
            }
        });
        var val = hidden.val() || '';
        select.val(val.split(';'))
        select.select2().on('change', function () {
            var selected = select.val() || [];
            hidden.val(selected.join(';'))
        })
        $('.additional-categories-wrapper').show();
    });

    $(function () {
        var testButton = $('#newswire-test-connection');
        var resultsContainer = $('#newswire-test-results');

        if (!testButton.length || !resultsContainer.length || typeof NewswireAdmin === 'undefined') {
            return;
        }

        var defaultButtonText = testButton.text();

        testButton.on('click', function (event) {
            event.preventDefault();
            runTests();
        });

        function runTests() {
            resultsContainer.html('<p>' + NewswireAdmin.i18n.runningTests + '</p>');
            testButton.prop('disabled', true).text(NewswireAdmin.i18n.runningTests);

            $.post(NewswireAdmin.ajaxUrl, {
                action: 'newswire_test_connection',
                _ajax_nonce: NewswireAdmin.nonce
            }).done(function (response) {
                if (response && response.success) {
                    renderResults(response.data);
                    return;
                }

                renderError(NewswireAdmin.i18n.unexpectedError);
            }).fail(function () {
                renderError(NewswireAdmin.i18n.unexpectedError);
            }).always(function () {
                testButton.prop('disabled', false).text(defaultButtonText);
            });
        }

        function renderResults(data) {
            if (!data) {
                renderError(NewswireAdmin.i18n.unexpectedError);
                return;
            }

            var overallClass = data.overall_status === 'SUCCESS' ? 'notice-success' : 'notice-error';
            var html = '<div class="notice ' + overallClass + '"><p>' + data.message + '</p></div>';

            if (data.results && data.results.length) {
                html += '<ul class="newswire-test-report">';
                $.each(data.results, function (index, result) {
                    var statusLabel = result.status === 'SUCCESS' ? '✅' : '⚠️';
                    html += '<li><strong>' + statusLabel + ' ' + result.label + ':</strong> ' + result.details + '</li>';
                });
                html += '</ul>';
            }

            resultsContainer.html(html);
        }

        function renderError(message) {
            resultsContainer.html('<div class="notice notice-error"><p>' + message + '</p></div>');
        }
    });

})(jQuery);
