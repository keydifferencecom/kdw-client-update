<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://
 * @since      1.0.0
 *
 * @package    Newswire
 * @subpackage Newswire/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
<div class="wrap">

    <h2><?php echo esc_html(get_admin_page_title()); ?></h2>

    <form method="post" name="cleanup_options" action="options.php">

        <?php
        //Grab all options
        $options = get_option($this->newswire_plugin);

        $categories = get_categories(array(
                "hide_empty" => 0,
                "type" => "post",
                'orderby' => 'name',
                'order' => 'ASC'
        ));

        function get_plugin_internal_option($options, $name, $default_value = null)
        {
            $option_value = $options ? $options[$name] : null;
            return sanitize_text_field($option_value !== null ? $option_value : $default_value);
        }

        // Cleanup
        $token = get_plugin_internal_option($options, 'token');
        $secret = get_plugin_internal_option($options, 'secret');
        $category = get_plugin_internal_option($options, 'category');
        $post_status = get_plugin_internal_option($options, 'post_status', 'publish');
        $use_client_image_for_featured_image = get_plugin_internal_option($options, 'use_client_image_for_featured_image', false);
        $add_feature_image_to_post = get_plugin_internal_option($options, 'add_feature_image_to_post', false);
        $additional_categories = get_plugin_internal_option($options, 'additional_categories', '');
        $upstream_domain = get_plugin_internal_option($options, 'upstream_domain', 'http://127.0.0.1:8000');
        $author_username = get_plugin_internal_option($options, 'author_username', 'Newswire');
        $author_email = get_plugin_internal_option($options, 'author_email', 'contact@newswire.org');
        $author_first_name = get_plugin_internal_option($options, 'author_first_name', 'Chainwire');
        $author_last_name = get_plugin_internal_option($options, 'author_last_name', '');
        $author_url = get_plugin_internal_option($options, 'author_url', 'http://127.0.0.1:8000/');
        $author_avatar = get_plugin_internal_option($options, 'author_avatar', '/storage/photos/1/1710465407.jpg');
        $author_twitter = get_plugin_internal_option($options, 'author_twitter');
        $author_facebook = get_plugin_internal_option($options, 'author_facebook');
        $author_google = get_plugin_internal_option($options, 'author_google');
        $author_tumblr = get_plugin_internal_option($options, 'author_tumblr');
        $author_instagram = get_plugin_internal_option($options, 'author_instagram');
        $author_pinterest = get_plugin_internal_option($options, 'author_pinterest');
        $unbranded_author_username = get_plugin_internal_option($options, 'unbranded_author_username', 'blockchainnews');
        $unbranded_author_email = get_plugin_internal_option($options, 'unbranded_author_email');
        $unbranded_author_first_name = get_plugin_internal_option($options, 'unbranded_author_first_name');
        $unbranded_author_url = get_plugin_internal_option($options, 'unbranded_author_url');
        $unbranded_author_avatar = get_plugin_internal_option($options, 'unbranded_author_avatar', '/wp-plugin/unbranded_author_avatar.png');
        $category_options = '';
        foreach ($categories as $c) {
            $category_options .= '<option value="' . $c->name . '" ' . ($c->name === $category ? 'selected="selected"' : '') . '>' . $c->name . '</option>';
        }

        $post_status_array = [
                [
                        'name' => 'publish',
                        'label' => 'Publish'
                ],
                [
                        'name' => 'draft',
                        'label' => 'Draft'
                ],
                [
                        'name' => 'pending',
                        'label' => 'Pending'
                ],
                [
                        'name' => 'private',
                        'label' => 'Private'
                ],
        ];

        $post_status_options = '';
        foreach ($post_status_array as $c) {
            $post_status_options .= '<option value="' . $c['name'] . '" ' . ($c['name'] === $post_status ? 'selected="selected"' : '') . '>' . $c['label'] . '</option>';
        }
        settings_fields($this->newswire_plugin);
        do_settings_sections($this->newswire_plugin);
        ?>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Your Category</p>
            <legend class="screen-reader-text"><span><?php _e('Your Category', $this->newswire_plugin); ?></span>
            </legend>
            <select class="regular-text" id="<?php echo $this->newswire_plugin; ?>-category"
                    name="<?php echo $this->newswire_plugin; ?>[category]"
                    value="<?php if (!empty($category)) echo $category; ?>">
                <?php echo $category_options ?>
            </select>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Default Post Status</p>
            <legend class="screen-reader-text"><span><?php _e('Post Status', $this->newswire_plugin); ?></span>
            </legend>
            <select class="regular-text" id="<?php echo $this->newswire_plugin; ?>-post_status"
                    name="<?php echo $this->newswire_plugin; ?>[post_status]"
                    value="<?php if (!empty($post_status)) echo $post_status; ?>">
                <?php echo $post_status_options ?>
            </select>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Your Key</p>
            <legend class="screen-reader-text"><span><?php _e('Your Token', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-token"
                   name="<?php echo $this->newswire_plugin; ?>[token]"
                   value="<?php if (!empty($token)) echo $token; ?>"/>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset>
            <p>Your Secret</p>
            <legend class="screen-reader-text"><span><?php _e('Your Secret', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-secret"
                   name="<?php echo $this->newswire_plugin; ?>[secret]"
                   value="<?php if (!empty($secret)) echo $secret; ?>"/>
        </fieldset>
        <h3><?php esc_html_e('Remote Source Configuration', $this->newswire_plugin); ?></h3>

        <fieldset>
            <p>Upstream Domain</p>
            <legend class="screen-reader-text"><span><?php _e('Upstream Domain', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-upstream_domain"
                   name="<?php echo $this->newswire_plugin; ?>[upstream_domain]"
                   placeholder="https://example.com"
                   value="<?php if (!empty($upstream_domain)) echo esc_attr($upstream_domain); ?>"/>
            <p class="description"><?php esc_html_e('Used for article verification and to resolve relative media URLs.', $this->newswire_plugin); ?></p>
        </fieldset>

        <h3><?php esc_html_e('Primary Author Profile', $this->newswire_plugin); ?></h3>

        <fieldset>
            <p>Author Username</p>
            <legend class="screen-reader-text"><span><?php _e('Author Username', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_username"
                   name="<?php echo $this->newswire_plugin; ?>[author_username]"
                   value="<?php if (!empty($author_username)) echo esc_attr($author_username); ?>"/>
        </fieldset>

        <fieldset>
            <p>Author Email</p>
            <legend class="screen-reader-text"><span><?php _e('Author Email', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_email"
                   name="<?php echo $this->newswire_plugin; ?>[author_email]"
                   value="<?php if (!empty($author_email)) echo esc_attr($author_email); ?>"/>
        </fieldset>

        <fieldset>
            <p>Author First Name</p>
            <legend class="screen-reader-text"><span><?php _e('Author First Name', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_first_name"
                   name="<?php echo $this->newswire_plugin; ?>[author_first_name]"
                   value="<?php if (!empty($author_first_name)) echo esc_attr($author_first_name); ?>"/>
        </fieldset>

        <fieldset>
            <p>Author Last Name</p>
            <legend class="screen-reader-text"><span><?php _e('Author Last Name', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_last_name"
                   name="<?php echo $this->newswire_plugin; ?>[author_last_name]"
                   value="<?php if (!empty($author_last_name)) echo esc_attr($author_last_name); ?>"/>
        </fieldset>

        <fieldset>
            <p>Author Website</p>
            <legend class="screen-reader-text"><span><?php _e('Author Website', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_url"
                   name="<?php echo $this->newswire_plugin; ?>[author_url]"
                   placeholder="https://example.com/profile"
                   value="<?php if (!empty($author_url)) echo esc_attr($author_url); ?>"/>
        </fieldset>

        <fieldset>
            <p>Author Avatar Path or URL</p>
            <legend class="screen-reader-text"><span><?php _e('Author Avatar', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_avatar"
                   name="<?php echo $this->newswire_plugin; ?>[author_avatar]"
                   placeholder="/path/to/avatar.png"
                   value="<?php if (!empty($author_avatar)) echo esc_attr($author_avatar); ?>"/>
            <p class="description"><?php esc_html_e('Relative paths will be resolved against the upstream domain.', $this->newswire_plugin); ?></p>
        </fieldset>

        <fieldset>
            <p><?php esc_html_e('Author Social Links', $this->newswire_plugin); ?></p>
            <legend class="screen-reader-text"><span><?php _e('Author Social Links', $this->newswire_plugin); ?></span>
            </legend>
            <label><?php esc_html_e('Twitter', $this->newswire_plugin); ?>
                <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_twitter"
                       name="<?php echo $this->newswire_plugin; ?>[author_twitter]"
                       value="<?php if (!empty($author_twitter)) echo esc_attr($author_twitter); ?>"/>
            </label><br>
            <label><?php esc_html_e('Facebook', $this->newswire_plugin); ?>
                <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_facebook"
                       name="<?php echo $this->newswire_plugin; ?>[author_facebook]"
                       value="<?php if (!empty($author_facebook)) echo esc_attr($author_facebook); ?>"/>
            </label><br>
            <label><?php esc_html_e('Google+', $this->newswire_plugin); ?>
                <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_google"
                       name="<?php echo $this->newswire_plugin; ?>[author_google]"
                       value="<?php if (!empty($author_google)) echo esc_attr($author_google); ?>"/>
            </label><br>
            <label><?php esc_html_e('Tumblr', $this->newswire_plugin); ?>
                <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_tumblr"
                       name="<?php echo $this->newswire_plugin; ?>[author_tumblr]"
                       value="<?php if (!empty($author_tumblr)) echo esc_attr($author_tumblr); ?>"/>
            </label><br>
            <label><?php esc_html_e('Instagram', $this->newswire_plugin); ?>
                <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_instagram"
                       name="<?php echo $this->newswire_plugin; ?>[author_instagram]"
                       value="<?php if (!empty($author_instagram)) echo esc_attr($author_instagram); ?>"/>
            </label><br>
            <label><?php esc_html_e('Pinterest', $this->newswire_plugin); ?>
                <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-author_pinterest"
                       name="<?php echo $this->newswire_plugin; ?>[author_pinterest]"
                       value="<?php if (!empty($author_pinterest)) echo esc_attr($author_pinterest); ?>"/>
            </label>
        </fieldset>

        <h3><?php esc_html_e('Unbranded Author Profile', $this->newswire_plugin); ?></h3>

        <fieldset>
            <p>Unbranded Author Username</p>
            <legend class="screen-reader-text"><span><?php _e('Unbranded Author Username', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-unbranded_author_username"
                   name="<?php echo $this->newswire_plugin; ?>[unbranded_author_username]"
                   value="<?php if (!empty($unbranded_author_username)) echo esc_attr($unbranded_author_username); ?>"/>
        </fieldset>

        <fieldset>
            <p>Unbranded Author Email</p>
            <legend class="screen-reader-text"><span><?php _e('Unbranded Author Email', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-unbranded_author_email"
                   name="<?php echo $this->newswire_plugin; ?>[unbranded_author_email]"
                   value="<?php if (!empty($unbranded_author_email)) echo esc_attr($unbranded_author_email); ?>"/>
        </fieldset>

        <fieldset>
            <p>Unbranded Author First Name</p>
            <legend class="screen-reader-text"><span><?php _e('Unbranded Author First Name', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-unbranded_author_first_name"
                   name="<?php echo $this->newswire_plugin; ?>[unbranded_author_first_name]"
                   value="<?php if (!empty($unbranded_author_first_name)) echo esc_attr($unbranded_author_first_name); ?>"/>
        </fieldset>

        <fieldset>
            <p>Unbranded Author Website</p>
            <legend class="screen-reader-text"><span><?php _e('Unbranded Author Website', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-unbranded_author_url"
                   name="<?php echo $this->newswire_plugin; ?>[unbranded_author_url]"
                   value="<?php if (!empty($unbranded_author_url)) echo esc_attr($unbranded_author_url); ?>"/>
        </fieldset>

        <fieldset>
            <p>Unbranded Author Avatar Path or URL</p>
            <legend class="screen-reader-text"><span><?php _e('Unbranded Author Avatar', $this->newswire_plugin); ?></span>
            </legend>
            <input class="regular-text" id="<?php echo $this->newswire_plugin; ?>-unbranded_author_avatar"
                   name="<?php echo $this->newswire_plugin; ?>[unbranded_author_avatar]"
                   value="<?php if (!empty($unbranded_author_avatar)) echo esc_attr($unbranded_author_avatar); ?>"/>
            <p class="description"><?php esc_html_e('Relative paths will be resolved against the upstream domain.', $this->newswire_plugin); ?></p>
        </fieldset>
        <p>Additional Options</p>

        <fieldset>
            <legend class="screen-reader-text">
                <span><?php _e('Use client logo instead of featured image', $this->newswire_plugin); ?></span>
            </legend>
            <label for="<?php echo $this->newswire_plugin; ?>-use_client_image_for_featured_image">
                <input class="regular-text"
                       id="<?php echo $this->newswire_plugin; ?>-use_client_image_for_featured_image"
                       type="checkbox"
                       name="<?php echo $this->newswire_plugin; ?>[use_client_image_for_featured_image]"
                    <?php if (!empty($use_client_image_for_featured_image)) echo 'checked="checked"'; ?>/>
                <span><?php _e('Use client logo instead of featured image', $this->newswire_plugin); ?></span>
            </label>
        </fieldset>

        <fieldset>
            <legend class="screen-reader-text">
                <span><?php _e('Add feature image to post content', $this->newswire_plugin); ?></span>
            </legend>
            <label for="<?php echo $this->newswire_plugin; ?>-add_feature_image_to_post">
                <input class="regular-text"
                       id="<?php echo $this->newswire_plugin; ?>-add_feature_image_to_post"
                       type="checkbox"
                       name="<?php echo $this->newswire_plugin; ?>[add_feature_image_to_post]"
                    <?php if (!empty($add_feature_image_to_post)) echo 'checked="checked"'; ?>/>
                <span><?php _e('Add feature image to post content', $this->newswire_plugin); ?></span>
            </label>
        </fieldset>

        <!-- load jQuery from CDN -->
        <fieldset class="additional-categories-wrapper" style="display: none">
            <p>Additional Categories</p>
            <legend class="screen-reader-text">
                <span><?php _e('Additional Categories', $this->newswire_plugin); ?></span>
            </legend>
            <select class="multiple-select regular-text"
                    multiple="multiple"
                    data-placeholder="Click here to select additional categories"
                    style="max-width: 22rem; width: 100% !important;"
                    name="categories[]">
                <?php echo $category_options ?>
            </select>
            <input type="hidden"
                   name="<?php echo $this->newswire_plugin; ?>[additional_categories]"
                   value="<?php if (!empty($additional_categories)) echo $additional_categories; ?>"
                   id="<?php echo $this->newswire_plugin; ?>-additional_categories">
        </fieldset>
        <fieldset>
            <legend class="screen-reader-text">
                <span><?php _e('Test Connection', $this->newswire_plugin); ?></span>
            </legend>
            <p><?php esc_html_e('Run a quick diagnostic to confirm your credentials and upstream domain are ready.', $this->newswire_plugin); ?></p>
            <button type="button" class="button" id="newswire-test-connection"><?php esc_html_e('Test Connection', $this->newswire_plugin); ?></button>
            <p class="description"><?php esc_html_e('Uses your saved settings to perform remote checks and report the results below.', $this->newswire_plugin); ?></p>
        </fieldset>

        <div id="newswire-test-results" class="newswire-test-results" aria-live="polite"></div>

        <!--        Add feature image to post content-->
        <?php submit_button('Save all changes', 'primary', 'submit', TRUE); ?>

    </form>

</div>
