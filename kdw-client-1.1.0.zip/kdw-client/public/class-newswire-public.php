<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://
 * @since      1.0.0
 *
 * @package    Newswire
 * @subpackage Newswire/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Newswire
 * @subpackage Newswire/public
 * @author
 */
class NewswirePublic
{

    const StatusError = 'ERROR';
    const StatusSuccess = 'SUCCESS';
    const PressReleaseBranded = 0;
    const PressReleaseUnbranded = 1;
    const PostDuplicatedExpirationTime = 259200; // 3 days
    const DateTimeFormat = 'Y-m-d H:i:s';
    const MAX_REMOTE_FILE_SIZE = 5242880; // 5 MB
    const REMOTE_REQUEST_ATTEMPTS = 2;
    const TRACE_ENDPOINT = '/wp-json/newswire-plugin/v1/article-traces';
    private $domain = 'http://127.0.0.1:8000';
    private $ssl_verify = true;
    private $allowed_download_host;
    private $allowed_download_port;
    private $author_username = 'Newswire';
    private $author_email = 'contact@newswire.org';
    private $author_first_name = 'Chainwire';
    private $author_url = 'http://127.0.0.1:8000/';
    private $author_avatar = '/storage/photos/1/1710465407.jpg';

    private $unbranded_author_username = 'blockchainnews';
    private $unbranded_author_email = null;
    private $unbranded_author_first_name = '';
    private $unbranded_author_url = null;
    private $unbranded_author_avatar = '/wp-plugin/unbranded_author_avatar.png';

    private $author_last_name = null;
    private $author_twitter = null;
    private $author_facebook = null;
    private $author_google = null;
    private $author_tumblr = null;
    private $author_instagram = null;
    private $author_pinterest = null;
    private $request_params = array();
    private $structured_payload = null;
    private $current_trace_id = null;
    // private $verify_post = true;

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $newswire_plugin The ID of this plugin.
     */
    private $newswire_plugin;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string $version The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @param string $newswire_plugin The name of the plugin.
     * @param string $version The version of this plugin.
     * @since    1.0.0
     */
    public function __construct($newswire_plugin, $version)
    {

        $this->newswire_plugin = $newswire_plugin;
        $this->version = $version;

        $this->apply_runtime_configuration();
        $this->refresh_download_host_restrictions();
        $this->ssl_verify = (bool)apply_filters('newswire_ssl_verify', $this->ssl_verify);

    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in NewswireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The NewswireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_style($this->newswire_plugin, plugin_dir_url(__FILE__) . 'css/newswire-public.css', array(), $this->version, 'all');

    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts()
    {

        /**
         * This function is provided for demonstration purposes only.
         *
         * An instance of this class should be passed to the run() function
         * defined in NewswireLoader as all of the hooks are defined
         * in that particular class.
         *
         * The NewswireLoader will then create the relationship
         * between the defined hooks and the functions defined in this
         * class.
         */

        wp_enqueue_script($this->newswire_plugin, plugin_dir_url(__FILE__) . 'js/newswire-public.js', array('jquery'), $this->version, false);

    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function custom_rest_api_init()
    {

        register_rest_route('newswire-plugin/v1', '/posts', array(
            'methods' => 'POST',
            'callback' => array($this, 'add_new_post'),
            'permission_callback' => array($this, 'rest_permission_check')
        ));

        register_rest_route('newswire-plugin/v1', '/verification', array(
            'methods' => 'POST',
            'callback' => array($this, 'verify_installation'),
            'permission_callback' => array($this, 'rest_permission_check')
        ));

        register_rest_route('newswire-plugin/v1', '/plugin-details', array(
            'methods' => 'POST',
            'callback' => array($this, 'check_plugin_details'),
            'permission_callback' => array($this, 'rest_permission_check')
        ));

    }

    protected function apply_runtime_configuration()
    {
        $options = get_option($this->newswire_plugin);

        if (!is_array($options)) {
            return;
        }

        if (array_key_exists('upstream_domain', $options)) {
            $domain = $this->sanitize_domain_option($options['upstream_domain']);
            if ($domain) {
                $this->domain = $domain;
            }
        }

        if (array_key_exists('author_username', $options)) {
            $this->author_username = $this->sanitize_required_text($options['author_username'], $this->author_username);
        }

        if (array_key_exists('author_email', $options)) {
            $this->author_email = $this->sanitize_optional_email($options['author_email'], $this->author_email);
        }

        if (array_key_exists('author_first_name', $options)) {
            $this->author_first_name = $this->sanitize_required_text($options['author_first_name'], $this->author_first_name);
        }

        if (array_key_exists('author_last_name', $options)) {
            $this->author_last_name = $this->sanitize_optional_text($options['author_last_name']);
        }

        if (array_key_exists('author_url', $options)) {
            $this->author_url = $this->sanitize_optional_url($options['author_url']);
        }

        if (array_key_exists('author_avatar', $options)) {
            $this->author_avatar = $this->sanitize_avatar_setting($options['author_avatar'], $this->author_avatar);
        }

        if (array_key_exists('author_twitter', $options)) {
            $this->author_twitter = $this->sanitize_optional_text($options['author_twitter']);
        }

        if (array_key_exists('author_facebook', $options)) {
            $this->author_facebook = $this->sanitize_optional_text($options['author_facebook']);
        }

        if (array_key_exists('author_google', $options)) {
            $this->author_google = $this->sanitize_optional_text($options['author_google']);
        }

        if (array_key_exists('author_tumblr', $options)) {
            $this->author_tumblr = $this->sanitize_optional_text($options['author_tumblr']);
        }

        if (array_key_exists('author_instagram', $options)) {
            $this->author_instagram = $this->sanitize_optional_text($options['author_instagram']);
        }

        if (array_key_exists('author_pinterest', $options)) {
            $this->author_pinterest = $this->sanitize_optional_text($options['author_pinterest']);
        }

        if (array_key_exists('unbranded_author_username', $options)) {
            $this->unbranded_author_username = $this->sanitize_required_text($options['unbranded_author_username'], $this->unbranded_author_username);
        }

        if (array_key_exists('unbranded_author_email', $options)) {
            $this->unbranded_author_email = $this->sanitize_optional_email($options['unbranded_author_email'], $this->unbranded_author_email);
        }

        if (array_key_exists('unbranded_author_first_name', $options)) {
            $this->unbranded_author_first_name = $this->sanitize_optional_text($options['unbranded_author_first_name']);
        }

        if (array_key_exists('unbranded_author_url', $options)) {
            $this->unbranded_author_url = $this->sanitize_optional_url($options['unbranded_author_url']);
        }

        if (array_key_exists('unbranded_author_avatar', $options)) {
            $this->unbranded_author_avatar = $this->sanitize_avatar_setting($options['unbranded_author_avatar'], $this->unbranded_author_avatar);
        }
    }

    protected function refresh_download_host_restrictions()
    {
        $this->allowed_download_host = wp_parse_url($this->domain, PHP_URL_HOST);
        $this->allowed_download_port = wp_parse_url($this->domain, PHP_URL_PORT);
    }

    protected function sanitize_domain_option($value)
    {
        $value = trim((string)$value);

        if ($value === '') {
            return null;
        }

        $url = esc_url_raw($value);

        if ($url === '') {
            return null;
        }

        return untrailingslashit($url);
    }

    protected function sanitize_required_text($value, $fallback)
    {
        $sanitized = sanitize_text_field($value);

        return $sanitized !== '' ? $sanitized : $fallback;
    }

    protected function sanitize_optional_text($value, $fallback = null)
    {
        $sanitized = sanitize_text_field($value);

        return $sanitized !== '' ? $sanitized : $fallback;
    }

    protected function sanitize_optional_email($value, $fallback = null)
    {
        $email = sanitize_email($value);

        return $email !== '' ? $email : $fallback;
    }

    protected function sanitize_optional_url($value, $fallback = null)
    {
        $value = trim((string)$value);

        if ($value === '') {
            return $fallback;
        }

        $url = esc_url_raw($value);

        return $url !== '' ? $url : $fallback;
    }

    protected function sanitize_avatar_setting($value, $fallback)
    {
        $value = trim((string)$value);

        if ($value === '') {
            return $fallback;
        }

        if (self::is_absolute($value)) {
            $url = esc_url_raw($value);

            return $url !== '' ? $url : $fallback;
        }

        return '/' . ltrim(sanitize_text_field($value), '/');
    }

    protected function capture_request_context($request = null)
    {
        $params = array();

        if ($request instanceof WP_REST_Request) {
            $params = $request->get_params();
            $json_params = $request->get_json_params();
            if (is_array($json_params)) {
                $params = array_merge($params, $json_params);
            }
        }

        if (!empty($_POST)) {
            $post_params = wp_unslash($_POST);
            if (is_array($post_params)) {
                $params = array_merge($params, $post_params);
            }
        }

        $this->request_params = is_array($params) ? $params : array();
        $this->structured_payload = $this->detect_structured_payload($this->request_params);
        $this->current_trace_id = $this->detect_trace_identifier($request, $this->request_params);
    }

    protected function clear_request_context()
    {
        $this->request_params = array();
        $this->structured_payload = null;
        $this->current_trace_id = null;
    }

    protected function detect_structured_payload(array $params)
    {
        if (!isset($params['title']) || !isset($params['content'])) {
            return null;
        }

        $title = $params['title'];
        $content = $params['content'];

        $has_title = is_string($title) || (is_array($title) && isset($title['rendered']));
        $has_content = is_string($content) || (is_array($content) && isset($content['rendered']));

        if (!$has_title || !$has_content) {
            return null;
        }

        if (isset($params['meta']) && !is_array($params['meta'])) {
            return null;
        }

        if (isset($params['terms']) && !is_array($params['terms'])) {
            return null;
        }

        return $params;
    }

    protected function detect_trace_identifier($request, array $params)
    {
        $trace_id = null;

        if ($request instanceof WP_REST_Request) {
            $trace_header = $request->get_header('x-newswire-trace');
            if ($trace_header !== null) {
                $trace_id = $this->sanitize_trace_identifier($trace_header);
            }
        }

        if (!$trace_id && isset($params['meta'])) {
            $meta = $params['meta'];
            if (is_object($meta)) {
                $meta = (array)$meta;
            }
            if (is_array($meta) && isset($meta['kdw_trace_id'])) {
                $trace_id = $this->sanitize_trace_identifier($meta['kdw_trace_id']);
            }
        }

        if (!$trace_id && isset($params['kdw_trace_id'])) {
            $trace_id = $this->sanitize_trace_identifier($params['kdw_trace_id']);
        }

        return $trace_id;
    }

    protected function sanitize_trace_identifier($value)
    {
        if (is_numeric($value)) {
            $trace = (int)$value;
            if ($trace > 0) {
                return $trace;
            }
        }

        return null;
    }

    protected function get_payload_text($value)
    {
        if (is_string($value)) {
            return $value;
        }

        if (is_array($value)) {
            if (isset($value['rendered']) && is_string($value['rendered'])) {
                return $value['rendered'];
            }
            return '';
        }

        if (is_object($value)) {
            $value = (array)$value;
            if (isset($value['rendered']) && is_string($value['rendered'])) {
                return $value['rendered'];
            }
            return '';
        }

        return (string)$value;
    }

    protected function extract_media_url_from_payload($media)
    {
        if (is_string($media)) {
            return $media;
        }

        if (!is_array($media)) {
            return null;
        }

        if (isset($media['source_url']) && is_string($media['source_url'])) {
            return $media['source_url'];
        }

        if (isset($media['url']) && is_string($media['url'])) {
            return $media['url'];
        }

        if (isset($media['media_details']) && is_array($media['media_details'])) {
            $sizes = isset($media['media_details']['sizes']) && is_array($media['media_details']['sizes']) ? $media['media_details']['sizes'] : array();
            foreach (array('full', 'large', 'medium') as $size_key) {
                if (isset($sizes[$size_key]['source_url']) && is_string($sizes[$size_key]['source_url'])) {
                    return $sizes[$size_key]['source_url'];
                }
            }
        }

        if (isset($media['guid'])) {
            if (is_array($media['guid']) && isset($media['guid']['rendered']) && is_string($media['guid']['rendered'])) {
                return $media['guid']['rendered'];
            }
            if (is_string($media['guid'])) {
                return $media['guid'];
            }
        }

        return null;
    }

    protected function resolve_terms_from_payload($terms_payload, $taxonomy)
    {
        if (is_object($terms_payload)) {
            $terms_payload = (array)$terms_payload;
        }

        if (!is_array($terms_payload) || !isset($terms_payload[$taxonomy])) {
            return array();
        }

        $terms = $terms_payload[$taxonomy];

        if (is_object($terms)) {
            $terms = (array)$terms;
        }

        if (!is_array($terms)) {
            return array();
        }

        $ids = array();
        $names = array();

        foreach ($terms as $term) {
            if (is_array($term)) {
                if (isset($term['id'])) {
                    $ids[] = (int)$term['id'];
                    continue;
                }
                if (isset($term['term_id'])) {
                    $ids[] = (int)$term['term_id'];
                    continue;
                }
                if (isset($term['slug'])) {
                    $slug = sanitize_title($term['slug']);
                    if ($slug !== '') {
                        $existing = get_term_by('slug', $slug, $taxonomy);
                        if ($existing) {
                            $ids[] = (int)$existing->term_id;
                            continue;
                        }
                    }
                }
                if (isset($term['name'])) {
                    $name = sanitize_text_field($term['name']);
                    if ($name !== '') {
                        $names[] = $name;
                    }
                    continue;
                }
            } elseif (is_numeric($term)) {
                $ids[] = (int)$term;
            } elseif (is_string($term)) {
                $names[] = sanitize_text_field($term);
            }
        }

        if ($taxonomy === 'category') {
            foreach ($names as $name) {
                if ($name === '') {
                    continue;
                }
                $existing = get_term_by('name', $name, $taxonomy);
                if ($existing) {
                    $ids[] = (int)$existing->term_id;
                } else {
                    $created = wp_insert_term($name, $taxonomy);
                    if (!is_wp_error($created) && isset($created['term_id'])) {
                        $ids[] = (int)$created['term_id'];
                    }
                }
            }

            $ids = array_map('intval', $ids);
            $ids = array_filter($ids);

            return array_values(array_unique($ids));
        }

        $resolved = array();

        foreach ($ids as $id) {
            $id = (int)$id;
            if ($id > 0) {
                $resolved[] = $id;
            }
        }

        foreach ($names as $name) {
            if ($name !== '') {
                $resolved[] = $name;
            }
        }

        return array_values(array_unique($resolved, SORT_REGULAR));
    }

    protected function to_bool($value)
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (bool)(int)$value;
        }

        if (is_string($value)) {
            $value = strtolower(trim($value));
            return in_array($value, array('1', 'true', 'yes', 'on'), true);
        }

        return false;
    }

    protected function resolve_remote_url($url)
    {
        $url = trim((string)$url);

        if ($url === '') {
            return null;
        }

        if (self::is_absolute($url)) {
            return $url;
        }

        if ($url[0] !== '/') {
            $url = '/' . $url;
        }

        return $this->domain . $url;
    }

    protected function perform_remote_get($url, array $args)
    {
        return $this->perform_remote_request('wp_remote_get', $url, $args);
    }

    protected function perform_remote_post($url, array $args)
    {
        return $this->perform_remote_request('wp_remote_post', $url, $args);
    }

    protected function perform_remote_request($callback, $url, array $args)
    {
        $attempts = 0;
        $last_error = null;

        while ($attempts < self::REMOTE_REQUEST_ATTEMPTS) {
            $response = call_user_func($callback, $url, $args);

            if (is_wp_error($response)) {
                $last_error = $response;
            } else {
                $code = (int)wp_remote_retrieve_response_code($response);

                if ($code >= 200 && $code < 300) {
                    return $response;
                }

                $message = wp_remote_retrieve_response_message($response);
                $last_error = new WP_Error(
                    'newswire_http_error',
                    sprintf(__('Unexpected HTTP %1$d received from %2$s.', 'newswire'), $code, $url),
                    array(
                        'status_code' => $code,
                        'response_message' => $message,
                    )
                );
            }

            $attempts++;
        }

        return $last_error ?: new WP_Error('newswire_http_error', __('Unable to reach the remote service.', 'newswire'));
    }

    protected function log_error($message, array $context = array())
    {

        if (!empty($context)) {
            $message .= ' ' . wp_json_encode($context);
        }

        $timestamp = function_exists('current_time') ? current_time('mysql') : gmdate('Y-m-d H:i:s');
        $log_entry = sprintf('[%s] Newswire: %s%s', $timestamp, $message, PHP_EOL);

        if (defined('WP_CONTENT_DIR')) {
            $log_dir = rtrim(WP_CONTENT_DIR, '/\\') . '/kdw-client';

            if (!is_dir($log_dir)) {
                if (function_exists('wp_mkdir_p')) {
                    wp_mkdir_p($log_dir);
                } else {
                    mkdir($log_dir, 0755, true);
                }
            }

            if (is_dir($log_dir) && is_writable($log_dir)) {
                $log_file = $log_dir . '/newswire.log';
                file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                return;
            }
        }

        error_log('Newswire: ' . $message);
    }

    /**
     * Validate REST API permissions using the shared credentials configured in the plugin.
     *
     * @param WP_REST_Request $request
     * @return bool|WP_Error
     */
    public function rest_permission_check($request)
    {
        $token = $request->get_header('x-newswire-token');
        $signature = $request->get_header('x-newswire-signature');

        if ($token === null) {
            $token = $request->get_param('token');
        }

        if ($signature === null) {
            $signature = $request->get_param('signature');
        }

        if ($this->credentials_are_valid($token, $signature)) {
            return true;
        }

        return new WP_Error('rest_forbidden', __('Invalid authentication details.', 'newswire'), array('status' => rest_authorization_required_code()));
    }

    /**
     * Retrieve the configured plugin credentials.
     *
     * @return array
     */
    protected function get_plugin_credentials($options = null)
    {
        if ($options === null) {
            $options = get_option($this->newswire_plugin);
        }
        $token = isset($options['token']) ? sanitize_text_field($options['token']) : '';
        $secret = isset($options['secret']) ? sanitize_text_field($options['secret']) : '';

        return array($token, $secret);
    }

    /**
     * Ensure the provided token and signature match the configured credentials.
     *
     * @param string|null $token
     * @param string|null $signature
     * @return bool
     */
    protected function credentials_are_valid($token, $signature, $options = null)
    {
        list($plugin_token, $plugin_secret) = $this->get_plugin_credentials($options);

        if (!$plugin_token || !$plugin_secret) {
            return false;
        }

        if (!is_string($token) || !hash_equals($plugin_token, (string)$token)) {
            return false;
        }

        if (!is_string($signature)) {
            return false;
        }

        $expected_signature = hash_hmac('sha256', $plugin_token, $plugin_secret);

        return hash_equals($expected_signature, (string)$signature);
    }

    protected function download_file($url)
    {
        if (!$url) {
            return new WP_Error('newswire_invalid_url', __('No remote URL was provided.', 'newswire'));
        }

        if (!$this->is_remote_download_allowed($url)) {
            return new WP_Error('newswire_disallowed_host', __('Remote downloads are restricted to the configured upstream domain.', 'newswire'));
        }

        $validated_url = wp_http_validate_url($url);
        if (!$validated_url) {
            return new WP_Error('newswire_invalid_url', __('The provided remote URL is invalid.', 'newswire'));
        }

        $response = $this->perform_remote_get($validated_url, array(
            'timeout' => 30,
            'redirection' => 3,
            'sslverify' => $this->ssl_verify,
            'reject_unsafe_urls' => true,
            'limit_response_size' => self::MAX_REMOTE_FILE_SIZE,
        ));

        if (is_wp_error($response)) {
            $this->log_error('Failed to download remote media.download_file.', array($response));
            return $response;
        }

        $body = wp_remote_retrieve_body($response);
        if ($body === null || $body === '') {
            return new WP_Error('newswire_empty_body', __('The remote server returned an empty response.', 'newswire'));
        }

        $path = wp_parse_url($validated_url, PHP_URL_PATH);
        $filename = $path ? wp_basename($path) : basename($validated_url);
        if (!$filename) {
            $this->log_error('newswire_filename_error');
            return new WP_Error('newswire_filename_error', __('Unable to determine a filename for the downloaded media.', 'newswire'));
        }

        $upload = wp_upload_bits($filename, null, $body);
        if (!empty($upload['error'])) {
            $this->log_error('newswire_upload_error');
            return new WP_Error('newswire_upload_error', $upload['error']);
        }

        return $upload;
    }

    /**
     * @param $url
     * @return array
     */
    protected function get_fixed_url($url)
    {
        $resolved_url = $this->resolve_remote_url($url);
        $attachment_id = null;

        if (!$resolved_url) {
            return [
                'url' => $url,
                'attachment_id' => $attachment_id
            ];
        }

        $upload = $this->download_file($resolved_url);

        if (is_wp_error($upload)) {
            $this->log_error('Failed to download remote media.', array(
                'url' => $resolved_url,
                'error' => $upload->get_error_message(),
            ));

            return [
                'url' => $resolved_url,
                'attachment_id' => $attachment_id
            ];
        }

        if (!empty($upload['url'])) {
            $resolved_url = $upload['url'];
        }

        if (!empty($upload['file'])) {
            $attachment_id = $this->set_attachment($upload['file']);
        }

        return [
            'url' => $resolved_url,
            'attachment_id' => $attachment_id
        ];
    }


    /**
     * @param $file
     * @param null $parent_post_id
     * @return int|WP_Error
     */
    protected function set_attachment($file, $parent_post_id = null)
    {
        $filename = basename($file);
        $wp_filetype = wp_check_filetype($filename, null);
        $attachment = array(
            'post_mime_type' => $wp_filetype['type'],
            'post_parent' => $parent_post_id,
            'post_title' => preg_replace('/\.[^.]+$/', '', $filename),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        $attachment_id = wp_insert_attachment($attachment, $file, $parent_post_id);
        if (!is_wp_error($attachment_id)) {
            require_once(ABSPATH . "wp-admin" . '/includes/image.php');
            $attachment_data = wp_generate_attachment_metadata($attachment_id, $file);
            wp_update_attachment_metadata($attachment_id, $attachment_data);
        }
        return $attachment_id;
    }

    /**
     * @param $url
     * @return false|int
     */
    protected static function is_absolute($url)
    {
        $parts = wp_parse_url($url);

        return $parts && !empty($parts['scheme']);
    }

    /**
     * Determine whether a remote URL is allowed to be downloaded.
     *
     * @param string $url
     * @return bool
     */
    protected function is_remote_download_allowed($url)
    {
        if (!$url) {
            return false;
        }

        $parts = wp_parse_url($url);

        if (!$parts || empty($parts['host'])) {
            return false;
        }

        $scheme = isset($parts['scheme']) ? strtolower($parts['scheme']) : '';
        if (!in_array($scheme, array('http', 'https'), true)) {
            return false;
        }

        if (!$this->allowed_download_host || strtolower($parts['host']) !== strtolower($this->allowed_download_host)) {
            return false;
        }

        $expected_port = $this->allowed_download_port;
        if ($expected_port !== null) {
            $port = isset($parts['port']) ? (int)$parts['port'] : null;
            if ($port === null) {
                $port = $scheme === 'https' ? 443 : 80;
            }
            if ((int)$expected_port !== $port) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param null $press_release_kind
     * @param bool $update_avatar
     * @return false|int|WP_Error
     * @throws Exception
     */
    protected function get_author_id($press_release_kind = null, $update_avatar = false)
    {
        $unbranded = $press_release_kind === self::PressReleaseUnbranded;

        if ($unbranded) {
            $username = $this->unbranded_author_username;
            $user_id = username_exists($username);
        } else {
            $username = $this->author_username;
            $user_id = username_exists($username);
        }

        if (!$user_id) {
            if ($unbranded) {
                $user_email = $this->unbranded_author_email;
            } else {
                $user_email = $this->author_email;
            }
            if ($user_email && email_exists($user_email)) {
                throw new Exception('User already exists.');
            }
            $random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);
            $user_id = wp_create_user($username, $random_password, $user_email);

            if ($user_id <= 0) {
                throw new Exception("User wasn't created");
            }

            $user = new WP_User($user_id);
            $user->set_role('author');

            $arr = [
                'ID' => $user_id, // this is the ID of the user you want to update.
                'first_name' => $this->author_first_name,
                'last_name' => $this->author_last_name,
                'user_url' => $this->author_url ? $this->author_url : '',
                'twitter' => $this->author_twitter,
                'facebook' => $this->author_facebook,
                'google' => $this->author_google,
                'tumblr' => $this->author_tumblr,
                'instagram' => $this->author_instagram,
                'pinterest' => $this->author_pinterest,
            ];

            if ($unbranded) {
                $arr['first_name'] = $this->unbranded_author_first_name;
                $arr['user_url'] = $this->unbranded_author_url ? $this->unbranded_author_url : '';
            }

            foreach ($arr as $k => $v) {
                if ($v === null || $v === '') {
                    delete_user_meta($user_id, $k);
                }
            }
            wp_update_user($arr);
            $update_avatar = true;
        }

        if ($update_avatar) {
            if ($unbranded) {
                $avatar = $this->unbranded_author_avatar;
            } else {
                $avatar = $this->author_avatar;
            }
            $this->set_avatar_for_user($avatar, $user_id);
        }

        return $user_id;
    }

    /**
     * @param $avatar_url
     * @param $user_id
     */
    protected function set_avatar_for_user($avatar_url, $user_id)
    {
        global $wpdb;

        $resolved_url = $this->resolve_remote_url($avatar_url);
        if (!$resolved_url) {
            return;
        }

        $upload = $this->download_file($resolved_url);
        if (is_wp_error($upload)) {
            $this->log_error('Failed to download author avatar.', array(
                'url' => $resolved_url,
                'error' => $upload->get_error_message(),
            ));

            return;
        }

        if (!empty($upload['file'])) {
            $attachment_id = $this->set_attachment($upload['file']);
            if ($attachment_id) {
                update_user_meta($user_id, $wpdb->get_blog_prefix() . 'user_avatar', $attachment_id);
            }
        }
    }


    /**
     * @param $categories
     * @return array
     */
    protected function get_categories($categories, $create_parent = false)
    {
        if (!$categories || !is_array($categories)) {
            $categories = [];
        }

        $connected = [];

        if ($create_parent) {
            $parent_category_name = 'Newswire';
            $parent_category_id = get_cat_ID($parent_category_name);

            if (!$parent_category_id) {
                $parent = wp_insert_term($parent_category_name, 'category');
                if (!is_wp_error($parent)) {
                    $parent_category_id = $parent['term_id'];
                }
            }

            if ($parent_category_id) {
                foreach ($categories as $category) {
                    $c = get_cat_ID($category);
                    if (!$c) {
                        $c = wp_insert_term($category, 'category', ['parent' => $parent_category_id]);
                        if (!is_wp_error($c)) {
                            $connected[] = $c['term_id'];
                        }
                    } else {
                        $connected[] = $c;
                    }
                }
                if (count($categories) === 0) {
                    $connected = [$parent_category_id];
                }
            }
        } else {
            foreach ($categories as $category) {
                $c = get_cat_ID($category);
                if (!$c) {
                    $c = wp_insert_term($category, 'category');
                    if (!is_wp_error($c)) {
                        $connected[] = $c['term_id'];
                    }
                } else {
                    $connected[] = $c;
                }
            }
        }
        return $connected;
    }

    protected function add_iframe($initArray)
    {
        $initArray['extended_valid_elements'] = "iframe[id|class|title|style|align|frameborder|height|longdesc|marginheight|marginwidth|name|scrolling|src|width]";
        return $initArray;
    }

    protected function verify_image_url($url)
    {
        if (!$url) {
            return null;
        }
        $supported_images = array(
            'gif',
            'jpg',
            'jpeg',
            'png'
        );
        $ext = strtolower(pathinfo($url, PATHINFO_EXTENSION)); // Using strtolower to overcome case sensitive
        return in_array($ext, $supported_images) ? $url : null;
    }


    /**
     * @param $html
     * @param array $options
     * @return array
     */
    protected function regenerate_html($html, $options = [])
    {
        $add_feature_image_to_post = $options['add_feature_image_to_post'];
        $use_client_image_for_featured_image = $options['use_client_image_for_featured_image'];
        $press_release_client_image = $options['press_release_client_image'];
        $press_release_featured_image = $options['press_release_featured_image'];
        $uploaded_feature_image = null;
        $uploaded_client_image = null;

        $press_release_client_image = $this->verify_image_url($press_release_client_image);
        $press_release_featured_image = $this->verify_image_url($press_release_featured_image);

        if ($use_client_image_for_featured_image && $press_release_client_image) {
            $uploaded_client_image = $this->get_fixed_url($press_release_client_image);
        }

        if ($press_release_featured_image) {
            $uploaded_feature_image = $this->get_fixed_url($press_release_featured_image);
        }

        $feature_image = $uploaded_client_image ? $uploaded_client_image : $uploaded_feature_image;

        $doc = new DOMDocument();
        if ($add_feature_image_to_post && $feature_image) {
            $src = $feature_image['url'];
            $attachment_id = $feature_image['attachment_id'];
            $src_set = null;
            if ($src) {
                if ($attachment_id) {
                    $src_set = wp_get_attachment_image_srcset($attachment_id);
                }
                $src_set_attribute = $src_set ? ' srcset="' . $src_set . '"' : '';
                $html = '<p><img alt="" src="' . $src . '"' . $src_set_attribute . '></p>' . $html;
            }
        }

        $internal_errors = libxml_use_internal_errors(true);
        $libxml_options = 0;

        if (defined('LIBXML_HTML_NOIMPLIED')) {
            $libxml_options |= LIBXML_HTML_NOIMPLIED;
        }

        if (defined('LIBXML_HTML_NODEFDTD')) {
            $libxml_options |= LIBXML_HTML_NODEFDTD;
        }

        $doc->loadHTML('<?xml encoding="utf-8" ?>' . $html, $libxml_options);

        libxml_clear_errors();
        libxml_use_internal_errors($internal_errors);
        $tags = $doc->getElementsByTagName('img');

        /** @var DOMNode $tag */
        foreach ($tags as $tag) {
            $img = $tag->getAttribute('src');
            $fixed_url = $this->get_fixed_url($img);
            $src = $fixed_url['url'];
            $attachment_id = $fixed_url['attachment_id'];
            if ($src) {
                if ($attachment_id) {
                    $src_set = wp_get_attachment_image_srcset($attachment_id);
                    if ($src_set) {
                        $tag->setAttribute('src_set', $src_set);
                    }
                    $src_large = wp_get_attachment_image_url($attachment_id, 'large');
                    $tag->setAttribute('src', $src_large);
                }
            }
        }

        return [
            'html' => $libxml_options ? $doc->saveHTML() : $this->extract_body_inner_html($doc),
            'feature_image' => $feature_image
        ];
    }

    protected function extract_body_inner_html(DOMDocument $doc)
    {
        $body = $doc->getElementsByTagName('body')->item(0);

        if (!$body) {
            return $doc->saveHTML();
        }

        $html = '';

        foreach ($body->childNodes as $child) {
            $html .= $doc->saveHTML($child);
        }

        return $html;
    }

    /**
     * @param $data
     * @return array|WP_Error
     */
    protected function send_post_request($data)
    {
        $url = $this->domain . '/api/wp-plugin/verify-article';
        $response = $this->perform_remote_post($url, array(
                'method' => 'POST',
                'timeout' => 30,
                'redirection' => 5,
                'httpversion' => '1.0',
                'blocking' => true,
                'headers' => array(),
                'body' => $data,
                'sslverify' => $this->ssl_verify,
                'reject_unsafe_urls' => true,
                'cookies' => array()
            )
        );
        if (is_wp_error($response)) {
            $this->log_error('Verification request failed.', array(
                'url' => $url,
                'error' => $response->get_error_message(),
            ));
        }
        return $response;
    }

    protected function finalize_publish_response(array $response, $success_message = '')
    {
        if (!$this->current_trace_id) {
            return $response;
        }

        if ($success_message === '') {
            $success_message = __('Article published successfully.', 'newswire');
        }

        $status = isset($response['status']) ? strtoupper((string)$response['status']) : '';

        if ($status === self::StatusSuccess) {
            $payload = isset($response['data']) ? $response['data'] : null;
            $this->send_trace_update('success', $success_message, $payload);
        } elseif ($status === self::StatusError) {
            $payload = isset($response['errors']) ? $response['errors'] : null;
            $this->send_trace_update('error', $this->determine_error_message($response), $payload);
        }

        return $response;
    }

    protected function determine_error_message(array $response)
    {
        $message = '';

        if (isset($response['errors'])) {
            $errors = $response['errors'];
            if (is_string($errors)) {
                $message = $errors;
            } elseif (is_array($errors)) {
                if (isset($errors['form']) && is_string($errors['form'])) {
                    $message = $errors['form'];
                } else {
                    foreach ($errors as $key => $error) {
                        if ($key === 'rid') {
                            continue;
                        }
                        if (is_string($error) && $error !== '') {
                            $message = $error;
                            break;
                        }
                    }
                }
            }
        }

        if ($message === '') {
            $message = __('Article delivery failed.', 'newswire');
        }

        return $message;
    }

    protected function send_trace_update($status, $message, $response = null)
    {
        if (!$this->current_trace_id) {
            return;
        }

        list($token, $secret) = $this->get_plugin_credentials();

        if (!$token || !$secret) {
            return;
        }

        $endpoint = sprintf('%s%s', $this->domain, self::TRACE_ENDPOINT);
        $payload = array(
            'status' => sanitize_key($status),
            'message' => wp_strip_all_tags((string)$message),
        );

        if ($response !== null && $response !== '') {
            $payload['response'] = $response;
        }

        $headers = array(
            'Content-Type' => 'application/json',
            'X-Newswire-Token' => $token,
            'X-Newswire-Signature' => hash_hmac('sha256', $token, $secret),
            'X-Newswire-Trace' => (string)$this->current_trace_id,
            'X-Origin-Host' => $_SERVER['HTTP_HOST'],
        );

        $args = array(
            'method' => 'POST',
            'timeout' => 15,
            'headers' => $headers,
            'body' => wp_json_encode($payload),
            'sslverify' => $this->ssl_verify,
            'reject_unsafe_urls' => true,
        );

        $result = $this->perform_remote_post($endpoint, $args);
        $this->log_error('Trace callback result.', array(
            'result' => $result,
        ));

        if (is_wp_error($result)) {
            $this->log_error('Trace callback failed.', array(
                'trace_id' => $this->current_trace_id,
                'error' => $result->get_error_message(),
            ));
        }
    }

    /**
     * @return string
     * @throws Exception
     */
    protected function get_current_date()
    {
        return current_datetime()->format(self::DateTimeFormat);
    }

    /**
     * @return string
     * @throws Exception
     */
    protected function get_fixed_date()
    {
        $date = $this->get_safe_post_field('press_release_date');
        if ($date === "now" || !$date) {
            return $this->get_current_date();
        } else {
            $date = get_date_from_gmt($date);
        }
        return $date;
    }

    public function add_new_post($request = null)
    {
        return $this->publish_new_post([
            'post_status' => null
        ], $request instanceof WP_REST_Request ? $request : null);
    }

    /**
     * @param $field
     * @param null $default_value
     * @return mixed
     */
    protected function get_safe_html_field($field, $default_value = null)
    {
        $value = $default_value;

        if (isset($this->request_params[$field])) {
            $value = $this->request_params[$field];
        } elseif (isset($_POST[$field])) {
            $value = $_POST[$field];
        }

        if ($value === null) {
            return $value;
        }

        if (is_string($value)) {
            $decoded = base64_decode($value, true);
            if ($decoded !== false && $decoded !== '') {
                $value = $decoded;
            }
        }

        if ($value && is_string($value)) {
            return wp_kses($value, array(
                'br' => array(),
                'strong' => array(),
                'bold' => array(),
                'b' => array(),
                'i' => array(),
                'ol' => array(),
                'ul' => array(),
                'li' => array(),
                'a' => array(
                    'href' => array(),
                    'title' => array(),
                    'target' => array(),
                    'rel' => array(),
                ),
                'img' => array(
                    'src' => array(),
                    'alt' => array(),
                ),
                'video' => array(),
                'h1' => array(),
                'h2' => array(),
                'h3' => array(),
                'h4' => array(),
                'h5' => array(),
                'h6' => array(),
                'p' => array(
                    'class' => array(),
                ),
                'blockquote' => array(),
                'u' => array(),
                'del' => array(),
                'span' => array(),
                'iframe' => array(
                    'src' => array(),
                    'width' => array(),
                    'height' => array(),
                    'frameborder' => array(),
                    'allow' => array(),
                    'allowfullscreen' => array(),
                    'referrerpolicy' => array(),
                    'loading' => array(),
                    'title' => array(),
                    'style' => array(),
                    'class' => array(),
                    'id' => array(),
                    'name' => array(),
                    'sandbox' => array(),
                    'scrolling' => array(),
                ),
            ));
        }
        return $value;
    }

    /**
     * @param $field
     * @param null $default_value
     * @return mixed
     */
    protected function get_safe_post_field($field, $default_value = null)
    {
        $value = $default_value;

        if (isset($this->request_params[$field])) {
            $value = $this->request_params[$field];
        } elseif (isset($_POST[$field])) {
            $value = $_POST[$field];
        }

        if (is_array($value)) {
            return $this->map_deep_value($value, 'sanitize_text_field');
        }

        return sanitize_text_field($value);
    }

    /**
     * @param $field
     * @param null $default_value
     * @return mixed
     */
    protected function get_safe_option($options, $field, $default_value = null)
    {
        return sanitize_text_field(isset($options[$field]) ? $options[$field] : $default_value);
    }

    /**
     * Check plugin details
     *
     * @return array
     * @throws Exception
     */
    public function check_plugin_details($request = null)
    {
        $this->capture_request_context($request instanceof WP_REST_Request ? $request : null);
        try {
            $token = $request->get_header('x-newswire-token');
            $signature = $request->get_header('x-newswire-signature');
            if ($token && $signature) {
                $options = get_option($this->newswire_plugin);
                if ($this->credentials_are_valid($token, $signature, $options)) {
                    $add_feature_image_to_post = $this->get_safe_option($options, 'add_feature_image_to_post');
                    $post_status = $this->get_safe_option($options, 'post_status');
                    $use_client_image_for_featured_image = $this->get_safe_option($options, 'use_client_image_for_featured_image');
                    $categories = $this->get_categories_for_post($options);
                    $plugin_version = $this->version;
                    $categories_names = [];
                    foreach ($categories as $category) {
                        $categories_names[] = get_the_category_by_ID($category);
                    }
                    return [
                        'status' => self::StatusSuccess,
                        'data' => [
                            'add_feature_image_to_post' => $add_feature_image_to_post,
                            'use_client_image_for_featured_image' => $use_client_image_for_featured_image,
                            'categories' => $categories_names,
                            'version' => $plugin_version,
                            'post_status' => $post_status,
                        ]
                    ];
                }
            }
            return [
                'status' => self::StatusError,
                'errors' => [
                    'form' => 'Wrong Data - credentials not set'
                ]
            ];
        } finally {
            $this->clear_request_context();
        }
    }

    public function verify_installation($request = null)
    {
        $this->capture_request_context($request instanceof WP_REST_Request ? $request : null);
        $verification_kind = $this->get_safe_post_field('verification_kind', 'installation');
        $data = $this->publish_new_post([
            'post_status' => 'draft'
        ], $request instanceof WP_REST_Request ? $request : null);
        if ($verification_kind === 'installation') {
            if ($data['status'] === self::StatusSuccess) {
                $post_data = $data['data'];
                $post_id = $post_data['post_id'];
                if ($post_id) {
                    wp_delete_post($post_id, true);
                }
            }
        }
        $this->clear_request_context();
        return $data;
    }

    /**
     * @return array
     * @throws Exception
     */
    protected function get_categories_for_post($options = [])
    {
        $custom_category = $this->get_safe_option($options, 'category');
        $additional_categories = $this->get_safe_option($options, 'additional_categories', '');
        $additional_categories = explode(';', (string)$additional_categories);
        $categories = $this->get_safe_post_field('press_release_categories', []);
        $categories = $this->get_categories($custom_category ? [$custom_category] : $categories);
        $categories_additional = [];
        if ($additional_categories) {
            $categories_additional = $this->get_categories($additional_categories);
            if (!$custom_category) {
                $categories = [];
            }
        }
        return array_merge($categories, $categories_additional);
    }

    /**
     * @param $title
     * @return mixed|null
     */
    protected function find_post_by_title($title)
    {
        $current_posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => array('publish', 'pending', 'draft', 'auto-draft', 'future', 'private', 'inherit'),
            'title' => $title,
        ));
        return isset($current_posts[0]) ? $current_posts[0] : null;
    }

    /**
     * @return array
     * @throws Exception
     */
    protected function publish_new_post($publish_options = [], $request = null)
    {
        $this->capture_request_context($request);
        $rid = $this->get_safe_post_field('rid');

        try {
            $token = $request->get_header('x-newswire-token');
            $signature = $request->get_header('x-newswire-signature');
            if ($token && $signature) {
                $options = get_option($this->newswire_plugin);
                $add_feature_image_to_post = $this->get_safe_option($options, 'add_feature_image_to_post');
                $use_client_image_for_featured_image = $this->get_safe_option($options, 'use_client_image_for_featured_image');

                if ($this->credentials_are_valid($token, $signature, $options)) {
                    $feature_options = array(
                        'add_feature_image_to_post' => $add_feature_image_to_post,
                        'use_client_image_for_featured_image' => $use_client_image_for_featured_image,
                    );

                    if ($this->structured_payload) {
                        $response = $this->publish_structured_post(
                            $this->structured_payload,
                            $options,
                            $publish_options,
                            $feature_options,
                            $rid
                        );
                        return $this->finalize_publish_response($response);
                    }

                    $response = $this->publish_legacy_post(
                        $options,
                        $publish_options,
                        $feature_options,
                        $rid
                    );
                    return $this->finalize_publish_response($response);
                }

                throw new Exception('Wrong token');
            }
        } catch (Exception $e) {
            $response = [
                'status' => self::StatusError,
                'errors' => [
                    'form' => $e->getMessage(),
                    'rid' => $rid
                ]
            ];
            return $this->finalize_publish_response($response);
        } finally {
            $this->clear_request_context();
        }

        $response = [
            'status' => self::StatusError,
            'errors' => [
                'form' => 'Wrong Data - credentials not set',
                'rid' => $rid
            ]
        ];
        return $this->finalize_publish_response($response);
    }

    protected function publish_structured_post(array $payload, array $options, array $publish_options, array $feature_options, $rid)
    {
        $title_raw = $this->get_payload_text(isset($payload['title']) ? $payload['title'] : '');
        $content = $this->get_payload_text(isset($payload['content']) ? $payload['content'] : '');

        if ($title_raw === '') {
            throw new Exception('Title is required.');
        }

        if ($content === '') {
            throw new Exception('Content is required.');
        }

        $excerpt_raw = isset($payload['excerpt']) ? $this->get_payload_text($payload['excerpt']) : '';
        $slug = isset($payload['slug']) ? sanitize_title($payload['slug']) : '';
        $payload_status = isset($payload['status']) ? sanitize_key($payload['status']) : '';
        $meta = isset($payload['meta']) ? $payload['meta'] : array();
        if (is_object($meta)) {
            $meta = (array)$meta;
        }
        $meta = is_array($meta) ? $meta : array();
        $terms_payload = isset($payload['terms']) ? $payload['terms'] : array();

        $title_sanitized = sanitize_text_field($title_raw);
        $content = wp_kses_post($content);

        $press_release_kind = isset($meta['press_release_kind']) ? (int)$meta['press_release_kind'] : self::PressReleaseBranded;
        $update_avatar = isset($meta['kdw_update_author_avatar']) ? $this->to_bool($meta['kdw_update_author_avatar']) : false;

        $author_id = $this->get_author_id($press_release_kind, $update_avatar);

        $featured_media_url = $this->extract_media_url_from_payload(isset($payload['featured_media']) ? $payload['featured_media'] : null);
        $override_media_url = null;
        if (isset($meta['kdw_override_image'])) {
            $override_media_url = $this->extract_media_url_from_payload($meta['kdw_override_image']);
        }

        $html_fixed = $this->regenerate_html($content, array(
            'add_feature_image_to_post' => $feature_options['add_feature_image_to_post'],
            'use_client_image_for_featured_image' => $feature_options['use_client_image_for_featured_image'],
            'press_release_featured_image' => $featured_media_url,
            'press_release_client_image' => $override_media_url
        ));

        $category_terms = $this->resolve_terms_from_payload($terms_payload, 'category');
        $tag_terms = $this->resolve_terms_from_payload($terms_payload, 'post_tag');

        $category_override = array();
        if (isset($meta['kdw_category_override'])) {
            $override_value = $meta['kdw_category_override'];
            if (!is_array($override_value)) {
                $override_value = array($override_value);
            }
            $category_override = array_filter(array_map('intval', $override_value));
        }

        $tag_override = array();
        if (isset($meta['kdw_tag_override'])) {
            $override_value = $meta['kdw_tag_override'];
            if (!is_array($override_value)) {
                $override_value = array($override_value);
            }
            $tag_override = array_filter(array_map('intval', $override_value));
        }

        $categories_to_assign = !empty($category_override) ? $category_override : $category_terms;
        if (empty($categories_to_assign)) {
            $categories_to_assign = $this->get_categories_for_post($options);
        }

        $categories_to_assign = array_values(array_map('intval', $categories_to_assign));

        $tags_to_assign = !empty($tag_override) ? $tag_override : $tag_terms;
        if (!is_array($tags_to_assign)) {
            $tags_to_assign = $tags_to_assign === null ? array() : array($tags_to_assign);
        }

        $post_status = '';
        if (isset($publish_options['post_status']) && $publish_options['post_status']) {
            $post_status = $publish_options['post_status'];
        } elseif ($payload_status) {
            $post_status = $payload_status;
        } else {
            $post_status = $this->get_safe_option($options, 'post_status');
        }
        if ($post_status === '') {
            $post_status = 'draft';
        }

        $date_gmt = isset($payload['date_gmt']) ? sanitize_text_field($payload['date_gmt']) : '';
        if ($date_gmt) {
            $date_local = get_date_from_gmt($date_gmt);
            if (!$date_local) {
                $date_local = $this->get_current_date();
                $date_gmt = get_gmt_from_date($date_local);
            }
        } else {
            $date_local = $this->get_current_date();
            $date_gmt = get_gmt_from_date($date_local);
        }

        $current_post = null;
        if ($slug !== '') {
            $current_post = get_page_by_path($slug, OBJECT, 'post');
        }
        $title_to_check = $title_sanitized;
        if (!$current_post && $title_to_check !== '') {
            $current_post = $this->find_post_by_title(esc_html($title_to_check));
            if (!$current_post && strpos($title_to_check, '&') !== false) {
                $current_post = $this->find_post_by_title($title_to_check);
                if (!$current_post) {
                    $current_post = $this->find_post_by_title(str_replace('&', 'and', $title_to_check));
                }
            }
        }
        if ($current_post) {
            $current_post_id = $current_post->ID;
            $current_post_timestamp = get_post_timestamp($current_post_id);
            $post_timestamp = strtotime($date_local);
            if ($post_timestamp && $current_post_timestamp) {
                if (abs($current_post_timestamp - $post_timestamp) < self::PostDuplicatedExpirationTime) {
                    return [
                        'status' => self::StatusSuccess,
                        'data' => [
                            'rid' => $rid,
                            'post_id' => $current_post_id,
                            'article_url' => get_permalink($current_post_id),
                            'published_at' => get_post_datetime($current_post_id)->format(self::DateTimeFormat),
                            'options' => $options
                        ]
                    ];
                }
            }
        }

        $postarr = array(
            'post_title' => $title_sanitized,
            'post_content' => $html_fixed['html'],
            'post_status' => $post_status,
            'post_author' => $author_id,
            'post_type' => 'post',
            'post_excerpt' => wp_strip_all_tags($excerpt_raw)
        );

        if ($slug !== '') {
            $postarr['post_name'] = $slug;
        }

        if ($date_local) {
            $postarr['post_date'] = $date_local;
        }

        if ($date_gmt) {
            $postarr['post_date_gmt'] = $date_gmt;
        }

        if (!empty($categories_to_assign)) {
            $postarr['post_category'] = $categories_to_assign;
        }

        $post_id = wp_insert_post($postarr, true);
        if ($post_id instanceof WP_Error) {
            throw new Exception('Incorrect data for post : ' . json_encode($post_id->errors));
        } elseif ($post_id === 0) {
            throw new Exception('Incorrect data for post : ' . json_encode($postarr));
        }

        if (!empty($categories_to_assign)) {
            wp_set_post_terms($post_id, $categories_to_assign, 'category');
        }

        wp_set_post_terms($post_id, $tags_to_assign, 'post_tag');

        if (!empty($html_fixed['feature_image']) && !empty($html_fixed['feature_image']['attachment_id'])) {
            set_post_thumbnail($post_id, $html_fixed['feature_image']['attachment_id']);
        }

        foreach ($meta as $meta_key => $meta_value) {
            if ($meta_key === 'press_release_kind') {
                $meta_value = (int)$meta_value;
            } elseif ($meta_key === 'kdw_origin') {
                $meta_value = esc_url_raw((string)$meta_value);
            } elseif ($meta_key === 'kdw_category_override' || $meta_key === 'kdw_tag_override') {
                if (!is_array($meta_value)) {
                    $meta_value = array($meta_value);
                }
                $meta_value = array_values(array_map('intval', $meta_value));
            } elseif ($meta_key === 'kdw_update_author_avatar') {
                $meta_value = $this->to_bool($meta_value);
            }

            if ($meta_value !== null) {
                update_post_meta($post_id, $meta_key, $meta_value);
            }
        }

        if ($featured_media_url) {
            update_post_meta($post_id, '_kdw_featured_media_source', esc_url_raw($featured_media_url));
        }

        if ($override_media_url) {
            update_post_meta($post_id, '_kdw_override_media_source', esc_url_raw($override_media_url));
        }

        $link = get_permalink($post_id);
        $published_at = get_the_date('c', $post_id);
        $sent_at = $this->get_safe_post_field('sent_at');
        $feature_image_data = !empty($html_fixed['feature_image']) && is_array($html_fixed['feature_image'])
            ? $html_fixed['feature_image']
            : array();

        $log_payload = $this->prepare_structured_post_log_payload(
            $rid,
            $post_id,
            $link,
            $published_at,
            $title_sanitized,
            $excerpt_raw,
            $html_fixed['html'],
            $post_status,
            $slug,
            $date_local,
            $date_gmt,
            $categories_to_assign,
            $tags_to_assign,
            $meta,
            $featured_media_url,
            $override_media_url,
            $feature_image_data,
            $payload,
            $sent_at
        );

        return [
            'status' => self::StatusSuccess,
            'data' => [
                'article_url' => $link,
                'published_at' => $published_at,
                'rid' => $rid,
                'sent_at' => $sent_at,
                'post_id' => $post_id,
                'log_payload' => $log_payload,
            ]
        ];
    }

    protected function prepare_structured_post_log_payload(
        $rid,
        $post_id,
        $article_url,
        $published_at,
        $title,
        $excerpt,
        $content_html,
        $post_status,
        $slug,
        $date_local,
        $date_gmt,
        array $categories,
        array $tags,
        array $meta,
        $featured_media_url,
        $override_media_url,
        array $feature_image,
        array $payload,
        $sent_at
    ) {
        $site_url = home_url();
        $feature_image_attachment_id = isset($feature_image['attachment_id']) ? (int)$feature_image['attachment_id'] : null;
        $feature_image_resolved_url = isset($feature_image['url']) ? esc_url_raw((string)$feature_image['url']) : null;

        $log_payload = array(
            'rid' => $rid,
            'site_url' => $site_url,
            'post' => array(
                'id' => (int)$post_id,
                'status' => $post_status,
                'slug' => $slug,
                'title' => $title,
                'excerpt' => wp_strip_all_tags($excerpt),
                'content' => $content_html,
                'article_url' => $article_url,
                'published_at' => $published_at,
                'dates' => array(
                    'local' => $date_local,
                    'gmt' => $date_gmt,
                ),
                'taxonomy' => array(
                    'categories' => array_values($categories),
                    'tags' => array_values($tags),
                ),
            ),
            'media' => array(
                'featured' => $featured_media_url ? esc_url_raw($featured_media_url) : null,
                'override' => $override_media_url ? esc_url_raw($override_media_url) : null,
                'attachment_id' => $feature_image_attachment_id,
                'resolved_url' => $feature_image_resolved_url,
            ),
            'meta' => $meta,
            'payload_source' => $this->sanitize_structured_source_payload($payload),
            'environment' => array(
                'plugin_version' => $this->version,
                'home_url' => $site_url,
                'sent_at' => $sent_at,
            ),
        );

        return $this->remove_null_values($log_payload);
    }

    protected function sanitize_structured_source_payload($payload)
    {
        if (is_object($payload)) {
            $payload = (array)$payload;
        }

        if (!is_array($payload)) {
            return array();
        }

        $normalized = array();

        if (array_key_exists('title', $payload)) {
            $normalized['title'] = $this->get_payload_text($payload['title']);
        }

        if (array_key_exists('content', $payload)) {
            $normalized['content'] = $this->get_payload_text($payload['content']);
        }

        if (array_key_exists('excerpt', $payload)) {
            $normalized['excerpt'] = $this->get_payload_text($payload['excerpt']);
        }

        if (array_key_exists('slug', $payload)) {
            $normalized['slug'] = sanitize_title($payload['slug']);
        }

        if (array_key_exists('status', $payload)) {
            $normalized['status'] = sanitize_key($payload['status']);
        }

        if (array_key_exists('meta', $payload)) {
            $normalized['meta'] = $this->sanitize_payload_meta_for_logging($payload['meta']);
        }

        if (array_key_exists('terms', $payload)) {
            $normalized['terms'] = $this->sanitize_payload_terms_for_logging($payload['terms']);
        }

        if (array_key_exists('featured_media', $payload)) {
            $media = $this->sanitize_payload_featured_media_for_logging($payload['featured_media']);
            if ($media) {
                $normalized['featured_media'] = $media;
            }
        }

        return $normalized;
    }

    protected function sanitize_payload_meta_for_logging($meta)
    {
        if (is_object($meta)) {
            $meta = (array)$meta;
        }

        if (!is_array($meta)) {
            return array();
        }

        return $this->map_deep_value($meta, array($this, 'sanitize_log_scalar'));
    }

    protected function map_deep_value($value, $callback)
    {
        if (function_exists('map_deep')) {
            return map_deep($value, $callback);
        }

        if (is_array($value)) {
            foreach ($value as $index => $item) {
                $value[$index] = $this->map_deep_value($item, $callback);
            }

            return $value;
        }

        if (is_object($value)) {
            foreach ($value as $property => $item) {
                $value->$property = $this->map_deep_value($item, $callback);
            }

            return $value;
        }

        if (is_callable($callback)) {
            return call_user_func($callback, $value);
        }

        return $value;
    }

    protected function sanitize_payload_terms_for_logging($terms)
    {
        if (is_object($terms)) {
            $terms = (array)$terms;
        }

        if (!is_array($terms)) {
            return array();
        }

        $result = array();

        foreach ($terms as $taxonomy => $term_values) {
            if (is_array($term_values)) {
                $result[$taxonomy] = array_values(array_filter(array_map('intval', $term_values)));
            } elseif ($term_values === null || $term_values === '') {
                $result[$taxonomy] = array();
            } else {
                $result[$taxonomy] = array((int)$term_values);
            }
        }

        return $result;
    }

    protected function sanitize_payload_featured_media_for_logging($media)
    {
        $url = $this->extract_media_url_from_payload($media);

        if (!$url) {
            return null;
        }

        return array(
            'source_url' => esc_url_raw($url),
        );
    }

    public function sanitize_log_scalar($value)
    {
        if (is_string($value)) {
            return sanitize_text_field($value);
        }

        return $value;
    }

    protected function remove_null_values(array $data)
    {
        foreach ($data as $key => $value) {
            if (is_array($value)) {
                $data[$key] = $this->remove_null_values($value);
            } elseif ($value === null) {
                unset($data[$key]);
            }
        }

        return $data;
    }

    protected function publish_legacy_post(array $options, array $publish_options, array $feature_options, $rid)
    {
        $title = $this->get_safe_post_field('press_release_title');
        $date = $this->get_fixed_date();
        $current_post = $this->find_post_by_title(esc_html($title));
        if (!$current_post) {
            if (strpos($title, '&') !== false) {
                $current_post = $this->find_post_by_title($title);
                if (!$current_post) {
                    $current_post = $this->find_post_by_title(str_replace('&', 'and', $title));
                }
            }
        }
        if ($current_post) {
            $current_post_id = $current_post->ID;
            $current_post_timestamp = get_post_timestamp($current_post_id);
            $post_date = strtotime($date);
            if ($post_date && $current_post_timestamp) {
                if (abs($current_post_timestamp - $post_date) < self::PostDuplicatedExpirationTime) {
                    return [
                        'status' => self::StatusSuccess,
                        'data' => [
                            'rid' => $rid,
                            'post_id' => $current_post_id,
                            'article_url' => get_permalink($current_post_id),
                            'published_at' => get_post_datetime($current_post_id)->format(self::DateTimeFormat),
                            'options' => $options
                        ]
                    ];
                }
            }
        }
        $press_release_featured_image = $this->get_safe_post_field('press_release_featured_image');
        $press_release_client_image = $this->get_safe_post_field('press_release_client_image');

        $html = $this->get_safe_html_field('press_release_html');
        $tags = $this->get_safe_post_field('press_release_tags', []);

        $press_release_kind = intval($this->get_safe_post_field('press_release_kind', self::PressReleaseBranded));
        $update_avatar = $this->get_safe_post_field('update_author_avatar');
        $author_id = $this->get_author_id($press_release_kind, $update_avatar);

        $html_fixed = $this->regenerate_html($html, [
            'add_feature_image_to_post' => $feature_options['add_feature_image_to_post'],
            'use_client_image_for_featured_image' => $feature_options['use_client_image_for_featured_image'],
            'press_release_featured_image' => $press_release_featured_image,
            'press_release_client_image' => $press_release_client_image
        ]);

        $categories = $this->get_categories_for_post($options);

        $post_status = isset($publish_options['post_status']) ? $publish_options['post_status'] : null;
        $post_status = $post_status ? $post_status : $this->get_safe_option($options, 'post_status');

        $my_post = array(
            'post_title' => $title,
            'post_content' => $html_fixed['html'],
            'post_date' => $date,
            'post_status' => $post_status,
            'post_author' => $author_id,
            'post_category' => $categories
        );

        $post_id = wp_insert_post($my_post, true);
        if ($post_id instanceof WP_Error) {
            throw new Exception('Incorrect data for post : ' . json_encode($post_id->errors));
        } else if ($post_id === 0) {
            throw new Exception('Incorrect data for post : ' . json_encode($my_post));
        }

        wp_set_post_tags($post_id, $tags);
        $link = get_permalink($post_id);
        $date = get_the_date('c', $post_id);

        if ($html_fixed['feature_image'] && $html_fixed['feature_image']['attachment_id']) {
            set_post_thumbnail($post_id, $html_fixed['feature_image']['attachment_id']);
        }

        return [
            'status' => self::StatusSuccess,
            'data' => [
                'article_url' => $link,
                'published_at' => $date,
                'rid' => $rid,
                'sent_at' => $this->get_safe_post_field('sent_at'),
                'post_id' => $post_id,
            ]
        ];
    }

}