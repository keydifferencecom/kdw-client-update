<?php

/**
 * Handles update checks for the Newswire plugin when distributed privately.
 */
class NewswireUpdater {

    /**
     * Plugin basename (e.g. kdw-client/newswire-plugin.php).
     *
     * @var string
     */
    private $plugin_basename;

    /**
     * Current plugin version.
     *
     * @var string
     */
    private $current_version;

    /**
     * URL pointing to a JSON document that describes the latest release.
     *
     * @var string
     */
    private $metadata_url;

    /**
     * Plugin slug used in the plugin information modal.
     *
     * @var string
     */
    private $slug;

    /**
     * Cache key used to store the remote metadata locally.
     *
     * @var string
     */
    private $cache_key;

    /**
     * Cache TTL for the remote metadata.
     *
     * @var int
     */
    private $cache_ttl;

    /**
     * @param string $plugin_basename Plugin basename returned by plugin_basename().
     * @param string $current_version Current plugin version.
     * @param string $metadata_url    URL to the remote JSON metadata.
     */
    public function __construct($plugin_basename, $current_version, $metadata_url) {
        $this->plugin_basename = $plugin_basename;
        $this->current_version = $current_version;
        $this->metadata_url = $metadata_url;
        $this->slug = $this->determine_slug($plugin_basename);
        $this->cache_key = 'newswire_update_metadata';
        $this->cache_ttl = 12 * HOUR_IN_SECONDS;
    }

    /**
     * Injects an update response into the plugin update transient when a newer version exists.
     *
     * @param stdClass $transient
     * @return stdClass
     */
    public function maybe_set_update($transient) {
        if (!is_object($transient) || empty($transient->checked)) {
            return $transient;
        }

        $remote = $this->get_remote_metadata();

        if (!$remote || empty($remote['version']) || empty($remote['download_url'])) {
            return $transient;
        }

        if (version_compare($this->current_version, $remote['version'], '>=')) {
            return $transient;
        }

        $update = new stdClass();
        $update->slug = $this->slug;
        $update->plugin = $this->plugin_basename;
        $update->new_version = $remote['version'];
        $update->package = $remote['download_url'];

        if (!empty($remote['tested'])) {
            $update->tested = $remote['tested'];
        }

        if (!empty($remote['requires'])) {
            $update->requires = $remote['requires'];
        }

        if (!empty($remote['requires_php'])) {
            $update->requires_php = $remote['requires_php'];
        }

        if (!empty($remote['icons']) && is_array($remote['icons'])) {
            $update->icons = $remote['icons'];
        }

        $transient->response[$this->plugin_basename] = $update;

        return $transient;
    }

    /**
     * Provides detailed plugin information for the "View details" modal.
     *
     * @param false|object $result
     * @param string       $action
     * @param object       $args
     * @return false|object
     */
    public function plugin_info($result, $action, $args) {
        if ($action !== 'plugin_information' || empty($args->slug) || $args->slug !== $this->slug) {
            return $result;
        }

        $remote = $this->get_remote_metadata();

        if (!$remote || empty($remote['version']) || empty($remote['download_url'])) {
            return $result;
        }

        $info = new stdClass();
        $info->name = !empty($remote['name']) ? $remote['name'] : 'Newswire Integration';
        $info->slug = $this->slug;
        $info->version = $remote['version'];
        $info->download_link = $remote['download_url'];
        $info->tested = !empty($remote['tested']) ? $remote['tested'] : '';
        $info->requires = !empty($remote['requires']) ? $remote['requires'] : '';
        $info->requires_php = !empty($remote['requires_php']) ? $remote['requires_php'] : '';
        $info->last_updated = !empty($remote['last_updated']) ? $remote['last_updated'] : '';
        $info->homepage = !empty($remote['homepage']) ? $remote['homepage'] : '';
        $info->author = !empty($remote['author']) ? $remote['author'] : '';
        $info->author_profile = !empty($remote['author_profile']) ? $remote['author_profile'] : '';
        $info->sections = !empty($remote['sections']) && is_array($remote['sections']) ? $remote['sections'] : array();
        $info->banners = !empty($remote['banners']) && is_array($remote['banners']) ? $remote['banners'] : array();
        $info->icons = !empty($remote['icons']) && is_array($remote['icons']) ? $remote['icons'] : array();

        return $info;
    }

    /**
     * Clear cached metadata after a plugin update.
     *
     * @param WP_Upgrader $upgrader_object
     * @param array       $options
     */
    public function clear_cached_version($upgrader_object, $options) {
        if (!isset($options['action'], $options['type']) || $options['action'] !== 'update' || $options['type'] !== 'plugin') {
            return;
        }

        delete_transient($this->cache_key);
    }

    /**
     * Resolve the plugin slug using the plugin basename.
     *
     * @param string $plugin_basename
     * @return string
     */
    private function determine_slug($plugin_basename) {
        $directory = dirname($plugin_basename);

        if ($directory === '.' || $directory === '\\' || $directory === '/') {
            return basename($plugin_basename, '.php');
        }

        return $directory;
    }

    /**
     * Retrieve the remote metadata from the configured URL.
     *
     * @return array|null
     */
    private function get_remote_metadata() {
        $cached = get_transient($this->cache_key);

        if ($cached !== false) {
            return $cached;
        }

        $response = wp_remote_get($this->metadata_url, array(
            'timeout' => 10,
            'headers' => array(
                'Accept' => 'application/json',
            ),
        ));

        if (is_wp_error($response)) {
            return null;
        }

        $status_code = wp_remote_retrieve_response_code($response);

        if ($status_code !== 200) {
            return null;
        }

        $body = wp_remote_retrieve_body($response);

        if (empty($body)) {
            return null;
        }

        $decoded = json_decode($body, true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
            return null;
        }

        set_transient($this->cache_key, $decoded, $this->cache_ttl);

        return $decoded;
    }
}