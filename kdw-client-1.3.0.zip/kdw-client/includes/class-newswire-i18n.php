<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://
 * @since      1.0.0
 *
 * @package    newswire
 * @subpackage newswire/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    newswire
 * @subpackage newswire/includes
 * @author     Your Name <konrad@cracsoft.com>
 */
class NewswireI18n
{


    /**
     * Load the plugin text domain for translation.
     *
     * @since    1.0.0
     */
    public function load_plugin_textdomain()
    {

        load_plugin_textdomain(
                'newswire',
                false,
                dirname(dirname(plugin_basename(__FILE__))) . '/languages/'
        );

    }



}
