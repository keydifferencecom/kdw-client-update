<?php
/**
 *
 * @link              https://
 * @since             1.0.0
 * @package           Newswire
 *
 * @wordpress-plugin
 * Plugin Name:       Newswire Integration
 * Plugin URI:        https://newswire.wordpress.com
 * Description:       Integrate Your Blog With blockchain news wire Platform
 * Version:           1.3.0
 * Author:            Minor
 * Author URI:        https://newswire.wordpress.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       newswire
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

define('PLUGIN_NAME_VERSION', '1.3.0');

define('NEWSWIRE_UPDATE_METADATA_URL', 'https://github.com/keydifferencecom/kdw-client-update/raw/refs/heads/main/update.json');

function activate_newswire_plugin()
{
	require_once plugin_dir_path(__FILE__) . 'includes/class-newswire-activator.php';
    NewswireActivator::activate();
}

function deactivate_newswire_plugin()
{
    require_once plugin_dir_path(__FILE__) . 'includes/class-newswire-deactivator.php';
    NewswireDeactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_newswire_plugin');
register_deactivation_hook(__FILE__, 'deactivate_newswire_plugin');

require plugin_dir_path(__FILE__) . 'includes/class-newswire.php';

function run_newswire_plugin()
{

    $plugin = new Newswire();
    $plugin->run();

}

run_newswire_plugin();